﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PauseManager : MonoBehaviour {

    // Use this for initialization
    void Start()
    {
        Debug.Log("Khela Hobe!!!");
    }

    // Update is called once per frame
    void Update()
    {
        //Debug.Log("Khela Hocche!!!");
    }

    public void ResumeButtonPress()
    {
        Debug.Log("Resume Button Pressed!!!");
    }
    public void MainMenuButtonPress()
    {
        Debug.Log("Main Menu Button Pressed!!!");
    }
}
