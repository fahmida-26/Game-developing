﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MenuManager : MonoBehaviour
{

    // Use this for initialization
    void Start()
    {
        Debug.Log("Khela Hobe!!!");
    }

    // Update is called once per frame
    void Update()
    {
        //Debug.Log("Khela Hocche!!!");
    }

    public void PlayButtonPress()
    {
        Debug.Log("Play Button Pressed!!!");
    }
    public void OptionButtonPress()
    {
        Debug.Log("Option Button Pressed!!!");
    }
    public void ExitButtonPress()
    {
        Debug.Log("Exit Button Pressed!!!");
    }
}