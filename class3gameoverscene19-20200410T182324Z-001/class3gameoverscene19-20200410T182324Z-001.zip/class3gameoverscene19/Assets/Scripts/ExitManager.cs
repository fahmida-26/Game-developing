﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ExitManager : MonoBehaviour {

    // Use this for initialization
    void Start()
    {
        Debug.Log("Khela Hobe!!!");
    }

    // Update is called once per frame
    void Update()
    {
        //Debug.Log("Khela Hocche!!!");
    }

    public void RetryButtonPress()
    {
        Debug.Log("Retry Button Pressed!!!");
    }
    public void MainMenuButtonPress()
    {
        Debug.Log("Main Menu Button Pressed!!!");
    }
    public void ExitButtonPress()
    {
        Debug.Log("Exit Button Pressed!!!");
    }
}
