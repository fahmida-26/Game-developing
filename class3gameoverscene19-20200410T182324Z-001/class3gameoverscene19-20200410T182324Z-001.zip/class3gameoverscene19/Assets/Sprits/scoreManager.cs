﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class scoreManager : MonoBehaviour {
    public int score = 0;
    public Text scoreTxt;
    // Use this for initializati
